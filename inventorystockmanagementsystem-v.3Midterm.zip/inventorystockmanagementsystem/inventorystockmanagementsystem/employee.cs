﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace inventorystockmanagementsystem
{
    public partial class employee : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public employee()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider = Microsoft.Jet.OLEDB.4.0; Data Source = C:\Users\zaid1\Desktop\Stock\DB\Stock.mdb";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stockDataSetEmployee);

        }

        private void employee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter1.Fill(this.employeeDataSet.employee);
            // TODO: This line of code loads data into the 'stockDataSetEmployee.employee' table. You can move, or remove it, as needed.


        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "insert into employee (employeeID, employeeFirstName, employeeLastName, streetAddress, city, state, postalCode, contactNum) values('" + txt_employeeID.Text + "','" + txt_employeeFirstName.Text + "', '" + txt_employeeAddress.Text + "', '" + txt_city.Text + "', '" + txt_st.Text + "',  '" + txt_zip.Text + "',  '" + txt_zip.Text + "' ) ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Saved");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_View_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "select * from employee";
                command.CommandText = query;

                OleDbDataAdapter da = new OleDbDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "update employee set employeeFirstName = '" + txt_employeeFirstName.Text + "', streetAddress = '" + txt_employeeAddress.Text + "', city = '" + txt_city.Text + "', state = '" + txt_st.Text + "' postalCode = " + txt_zip.Text + " where employeeID = " +txt_employeeID.Text +" ";
                MessageBox.Show(query);
                command.CommandText = query;

                command.ExecuteNonQuery();
                MessageBox.Show("Data Edit Successfully!");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "delete from employee where  employeeID = " + txt_employeeID.Text + " ";
                command.ExecuteNonQuery();
                MessageBox.Show("Data Deleted");
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
                connection.Close();
            }
        }
    }
}
