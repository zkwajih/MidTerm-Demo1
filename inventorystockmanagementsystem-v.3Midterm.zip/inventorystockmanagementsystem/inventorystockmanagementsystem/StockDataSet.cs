﻿namespace inventorystockmanagementsystem
{


    partial class StockDataSet
    {
    }
}

namespace inventorystockmanagementsystem.StockDataSetTableAdapters {
    
    
    public partial class LoginTableAdapter {
    }
}
