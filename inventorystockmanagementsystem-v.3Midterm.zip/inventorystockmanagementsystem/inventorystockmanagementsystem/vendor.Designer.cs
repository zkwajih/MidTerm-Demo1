﻿
namespace inventorystockmanagementsystem
{
    partial class vendor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.stockDataSet = new inventorystockmanagementsystem.StockDataSet();
            this.companyMstBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.companyMstTableAdapter = new inventorystockmanagementsystem.StockDataSetTableAdapters.CompanyMstTableAdapter();
            this.tableAdapterManager = new inventorystockmanagementsystem.StockDataSetTableAdapters.TableAdapterManager();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_view = new System.Windows.Forms.Button();
            this.btn_edit = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.txt_vendorID = new System.Windows.Forms.TextBox();
            this.txt_vendorName = new System.Windows.Forms.TextBox();
            this.txt_vendorAddress = new System.Windows.Forms.TextBox();
            this.txt_ContactName = new System.Windows.Forms.TextBox();
            this.txt_PhoneNumebr = new System.Windows.Forms.TextBox();
            this.vendorBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.vendorDataSet = new inventorystockmanagementsystem.vendorDataSet();
            this.vendorBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.vendorTableAdapter = new inventorystockmanagementsystem.vendorDataSetTableAdapters.vendorTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.stockDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyMstBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vendor ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(156, 60);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Vendor Name ";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(421, 179);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 44);
            this.button1.TabIndex = 3;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(187, 178);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 44);
            this.button2.TabIndex = 2;
            this.button2.Text = "Add";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // stockDataSet
            // 
            this.stockDataSet.DataSetName = "StockDataSet";
            this.stockDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // companyMstBindingSource
            // 
            this.companyMstBindingSource.DataMember = "CompanyMst";
            this.companyMstBindingSource.DataSource = this.stockDataSet;
            // 
            // companyMstTableAdapter
            // 
            this.companyMstTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BillPaymentMstTableAdapter = null;
            this.tableAdapterManager.CompanyMstTableAdapter = this.companyMstTableAdapter;
            this.tableAdapterManager.ComPaymentMstTableAdapter = null;
            this.tableAdapterManager.employeeTableAdapter = null;
            this.tableAdapterManager.LoginTableAdapter = null;
            this.tableAdapterManager.OrderReturnMstTableAdapter = null;
            this.tableAdapterManager.PaymentMstTableAdapter = null;
            this.tableAdapterManager.positionTableAdapter = null;
            this.tableAdapterManager.productTableAdapter = null;
            this.tableAdapterManager.SellMstTableAdapter = null;
            this.tableAdapterManager.StockMstTableAdapter = null;
            this.tableAdapterManager.StockReturnMstTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = inventorystockmanagementsystem.StockDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UserMstTableAdapter = null;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(315, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Address";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(691, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Phone Number ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(522, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Contact Name ";
            // 
            // btn_view
            // 
            this.btn_view.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view.Location = new System.Drawing.Point(303, 179);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(86, 44);
            this.btn_view.TabIndex = 9;
            this.btn_view.Text = "View";
            this.btn_view.UseVisualStyleBackColor = true;
            this.btn_view.Click += new System.EventHandler(this.btn_view_Click);
            // 
            // btn_edit
            // 
            this.btn_edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_edit.Location = new System.Drawing.Point(540, 180);
            this.btn_edit.Name = "btn_edit";
            this.btn_edit.Size = new System.Drawing.Size(86, 43);
            this.btn_edit.TabIndex = 10;
            this.btn_edit.Text = "Edit ";
            this.btn_edit.UseVisualStyleBackColor = true;
            this.btn_edit.Click += new System.EventHandler(this.btn_edit_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.Location = new System.Drawing.Point(660, 180);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(86, 42);
            this.btn_clear.TabIndex = 11;
            this.btn_clear.Text = "Clear ";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // txt_vendorID
            // 
            this.txt_vendorID.Location = new System.Drawing.Point(46, 102);
            this.txt_vendorID.Name = "txt_vendorID";
            this.txt_vendorID.Size = new System.Drawing.Size(72, 20);
            this.txt_vendorID.TabIndex = 12;
            // 
            // txt_vendorName
            // 
            this.txt_vendorName.Location = new System.Drawing.Point(160, 101);
            this.txt_vendorName.Name = "txt_vendorName";
            this.txt_vendorName.Size = new System.Drawing.Size(100, 20);
            this.txt_vendorName.TabIndex = 13;
            // 
            // txt_vendorAddress
            // 
            this.txt_vendorAddress.Location = new System.Drawing.Point(319, 101);
            this.txt_vendorAddress.Name = "txt_vendorAddress";
            this.txt_vendorAddress.Size = new System.Drawing.Size(178, 20);
            this.txt_vendorAddress.TabIndex = 14;
            // 
            // txt_ContactName
            // 
            this.txt_ContactName.Location = new System.Drawing.Point(526, 101);
            this.txt_ContactName.Name = "txt_ContactName";
            this.txt_ContactName.Size = new System.Drawing.Size(100, 20);
            this.txt_ContactName.TabIndex = 15;
            // 
            // txt_PhoneNumebr
            // 
            this.txt_PhoneNumebr.Location = new System.Drawing.Point(695, 101);
            this.txt_PhoneNumebr.Name = "txt_PhoneNumebr";
            this.txt_PhoneNumebr.Size = new System.Drawing.Size(100, 20);
            this.txt_PhoneNumebr.TabIndex = 16;
            // 
            // vendorBindingSource
            // 
            this.vendorBindingSource.DataMember = "vendor";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(46, 303);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(926, 440);
            this.dataGridView1.TabIndex = 17;
            // 
            // vendorDataSet
            // 
            this.vendorDataSet.DataSetName = "vendorDataSet";
            this.vendorDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vendorBindingSource1
            // 
            this.vendorBindingSource1.DataMember = "vendor";
            this.vendorBindingSource1.DataSource = this.vendorDataSet;
            // 
            // vendorTableAdapter
            // 
            this.vendorTableAdapter.ClearBeforeFill = true;
            // 
            // vendor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1104, 772);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_PhoneNumebr);
            this.Controls.Add(this.txt_ContactName);
            this.Controls.Add(this.txt_vendorAddress);
            this.Controls.Add(this.txt_vendorName);
            this.Controls.Add(this.txt_vendorID);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_edit);
            this.Controls.Add(this.btn_view);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "vendor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Vendor";
            this.Load += new System.EventHandler(this.vendor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stockDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.companyMstBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private StockDataSet stockDataSet;
        private System.Windows.Forms.BindingSource companyMstBindingSource;
        private StockDataSetTableAdapters.CompanyMstTableAdapter companyMstTableAdapter;
        private StockDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_view;
        private System.Windows.Forms.Button btn_edit;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.TextBox txt_vendorID;
        private System.Windows.Forms.TextBox txt_vendorName;
        private System.Windows.Forms.TextBox txt_vendorAddress;
        private System.Windows.Forms.TextBox txt_ContactName;
        private System.Windows.Forms.TextBox txt_PhoneNumebr;

        private System.Windows.Forms.BindingSource vendorBindingSource;
        private System.Windows.Forms.DataGridView dataGridView1;
        private vendorDataSet vendorDataSet;
        private System.Windows.Forms.BindingSource vendorBindingSource1;
        private vendorDataSetTableAdapters.vendorTableAdapter vendorTableAdapter;
    }
}